export type WalletSelection = "shared" | "wife" | "husband";

export type TransactionType = "income" | "expense" | "savings" | "debt";

export type ExpenseCategory =
  | "Food"
  | "Transport"
  | "Shopping"
  | "Rent"
  | "Internet"
  | "Entertainment"
  | "Gifts"
  | "Bills"
  | "Healthcare"
  | "Other";

export interface Transaction {
  id: string;
  amount: number;
  category: ExpenseCategory | "Income" | "Savings Contribution" | "Debt Settlement";
  date: string;
  notes: string;
  wallet: WalletSelection;
  type: TransactionType;
  addedBy: "wife" | "husband";
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  savedAmount: number;
  deadline: string;
  completed: boolean;
  category: "Emergency" | "Baby" | "House" | "Car" | "Wedding" | "Travel" | "Other";
}

export interface Budget {
  monthlyLimit: number; // overall limit
  categoryLimits: Record<ExpenseCategory, number>;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  type: "info" | "alert" | "success" | "celebration";
}

export interface CoupleProfile {
  wifeName: string;
  husbandName: string;
  avatarWife?: string; // custom emoji or link
  avatarHusband?: string; // custom emoji or link
  anniversaryDate?: string;
}

export interface AISuggestions {
  analysis: string;
  recommendations: string[];
  highestSpendingCategory: string;
  tips: string[];
  isFallback: boolean;
}

export interface BunaDate {
  id: string;
  date: string;
  brewer: "wife" | "husband";
  notes: string;
}
