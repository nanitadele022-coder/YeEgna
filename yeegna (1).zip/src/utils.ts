import { Transaction, SavingsGoal, Budget, NotificationItem, CoupleProfile } from "./types";

export const STARTING_COUPLE: CoupleProfile = {
  wifeName: "Belen",
  husbandName: "Michael",
  avatarWife: "🌸",
  avatarHusband: "🧸",
  anniversaryDate: "2024-10-12",
};

export const STARTING_BUDGET: Budget = {
  monthlyLimit: 25000,
  categoryLimits: {
    Food: 5000,
    Transport: 2500,
    Shopping: 4000,
    Rent: 12000,
    Internet: 1000,
    Entertainment: 3000,
    Gifts: 2000,
    Bills: 4000,
    Healthcare: 1500,
    Other: 2000,
  },
};

export const STARTING_TRANS: Transaction[] = [
  {
    id: "t1",
    amount: 55000,
    category: "Income",
    date: "2026-05-01",
    notes: "Combined Payday Contribution! 💖",
    wallet: "shared",
    type: "income",
    addedBy: "husband",
  },
  {
    id: "t2",
    amount: 1200,
    category: "Food",
    date: "2026-05-20",
    notes: "Cozy Candlelight Dinner at Kuriftu Resort 🕯️",
    wallet: "shared",
    type: "expense",
    addedBy: "wife",
  },
  {
    id: "t3",
    amount: 750,
    category: "Gifts",
    date: "2026-05-22",
    notes: "Anniversary Roses from Shola Market & Chocolate Box 🌹",
    wallet: "shared",
    type: "expense",
    addedBy: "husband",
  },
  {
    id: "t4",
    amount: 4500,
    category: "Shopping",
    date: "2026-05-24",
    notes: "Elegant Living Room Mesob - Pinterest style ✨",
    wallet: "shared",
    type: "expense",
    addedBy: "wife",
  },
  {
    id: "t5",
    amount: 1200,
    category: "Healthcare",
    date: "2026-05-25",
    notes: "Relaxing Traditional Spa Treatment 💆‍♀️",
    wallet: "wife",
    type: "expense",
    addedBy: "wife",
  },
  {
    id: "t6",
    amount: 1800,
    category: "Shopping",
    date: "2026-05-26",
    notes: "Mechanical Keyboard & Ergonomic desk setup ⌨️",
    wallet: "husband",
    type: "expense",
    addedBy: "husband",
  },
  {
    id: "t7",
    amount: 800,
    category: "Internet",
    date: "2026-05-15",
    notes: "Monthly Internet Bill (Ethio Telecom Fiber) 🌐",
    wallet: "shared",
    type: "expense",
    addedBy: "husband",
  },
];

export const STARTING_GOALS: SavingsGoal[] = [
  {
    id: "g1",
    title: "Our Dream Nest Apartment Fund 🏡",
    targetAmount: 1800000,
    savedAmount: 520000,
    deadline: "2030-06-01",
    completed: false,
    category: "House",
  },
  {
    id: "g2",
    title: "Sweet Romantic Weekend at Langano Lake 🌅🌸",
    targetAmount: 45000,
    savedAmount: 45000,
    deadline: "2026-08-10",
    completed: true,
    category: "Travel",
  },
  {
    id: "g3",
    title: "Sweet Little Baby Fund 🍼👼",
    targetAmount: 150000,
    savedAmount: 42000,
    deadline: "2027-12-15",
    completed: false,
    category: "Baby",
  },
  {
    id: "g4",
    title: "Cute Little Ride / Car Fund 🚗✨",
    targetAmount: 450000,
    savedAmount: 124000,
    deadline: "2028-10-01",
    completed: false,
    category: "Car",
  },
];

export const STARTING_NOTIFS: NotificationItem[] = [
  {
    id: "n1",
    title: "Dream Goal Met! 🎉",
    message: "Hooray! Belen and Michael achieved their 'Sweet Romantic Weekend at Langano Lake' dream goal! 🌅 Time to pack!",
    date: "2026-05-25 10:00",
    read: false,
    type: "celebration",
  },
  {
    id: "n2",
    title: "Shopping Spending Plan Alert! ⚠️",
    message: "Oops! Your combined Shopping is at 4,500 Birr, which is more than your 4,000 Birr spending plan. Let's talk kindly together! 💕",
    date: "2026-05-24 16:30",
    read: false,
    type: "alert",
  },
  {
    id: "n3",
    title: "New Joint Spend Added 🌸",
    message: "Michael added 'Anniversary Roses from Shola Market & Chocolate Box (750 Birr)' to Our Money space.",
    date: "2026-05-22 09:12",
    read: true,
    type: "info",
  },
];

export const MOTIVATIONAL_TIPS = [
  "When we trust each other with our money, we build our dreams twice as fast! 💖",
  "A spending plan isn't about restriction; it's about helping our hard-earned Birr to grow, holding hands all the way. ✨",
  "A money talk date once a week with traditional Buna (coffee) and popcorn keeps stress away! ☕🍿",
  "Having our own 'My Money' spaces lets us surprise each other with sweet spontaneous gifts! 🎁💞",
  "Every small Birr we save together on unnecessary shopping is another stone on our path to a gorgeous shared villa! 🏡💑",
];

// Helper to calculate total spending by wallet & category
export function calculateBalances(transactions: Transaction[], baseBudget?: number) {
  let wifeBalance = 15000; // base starting in Birr
  let husbandBalance = 17500; // base starting in Birr
  let sharedBalance = 100000; // base starting in Birr

  transactions.forEach((t) => {
    const amt = Number(t.amount);
    if (t.type === "income") {
      if (t.wallet === "wife") wifeBalance += amt;
      else if (t.wallet === "husband") husbandBalance += amt;
      else sharedBalance += amt;
    } else if (t.type === "expense" || t.type === "savings") {
      // savings reduces current available balance and adds to saved goals
      if (t.wallet === "wife") wifeBalance -= amt;
      else if (t.wallet === "husband") husbandBalance -= amt;
      else sharedBalance -= amt;
    }
  });

  return {
    wife: wifeBalance,
    husband: husbandBalance,
    shared: sharedBalance,
  };
}
