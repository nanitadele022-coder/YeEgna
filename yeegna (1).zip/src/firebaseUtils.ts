import {
  doc,
  setDoc,
  getDoc,
  updateDoc,
  deleteDoc,
  collection,
  writeBatch,
} from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "./firebase";
import { Transaction, SavingsGoal, Budget, NotificationItem, CoupleProfile, BunaDate } from "./types";
import { STARTING_BUDGET, STARTING_TRANS, STARTING_GOALS, STARTING_NOTIFS } from "./utils";

const COUPLES_COLL = "couples";
const TRANS_SUB = "transactions";
const GOALS_SUB = "goals";
const NOTIFS_SUB = "notifications";
const BUNA_SUB = "buna_dates";

/**
 * Seeds a newly registered couple account with starter templates
 */
export async function seedCoupleData(uid: string, profile: CoupleProfile) {
  const path = `${COUPLES_COLL}/${uid}`;
  try {
    // 1. Write core couple profile with starting budget
    const budget = STARTING_BUDGET;
    await setDoc(doc(db, COUPLES_COLL, uid), {
      ...profile,
      budget,
    });

    // 2. Batch add default starting transitions
    for (const t of STARTING_TRANS) {
      await setDoc(doc(db, path, TRANS_SUB, t.id), {
        ...t,
        createdAt: new Date().toISOString(),
      });
    }

    // 3. Batch add default starting savings goals
    for (const g of STARTING_GOALS) {
      await setDoc(doc(db, path, GOALS_SUB, g.id), {
        ...g,
        updatedAt: new Date().toISOString(),
      });
    }

    // 4. Batch add default starting notifications
    for (const n of STARTING_NOTIFS) {
      await setDoc(doc(db, path, NOTIFS_SUB, n.id), {
        ...n,
        createdAt: new Date().toISOString(),
      });
    }

  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Fetch a couple's profile configuration
 */
export async function getCoupleProfile(uid: string): Promise<any | null> {
  const path = `${COUPLES_COLL}/${uid}`;
  try {
    const snap = await getDoc(doc(db, COUPLES_COLL, uid));
    if (snap.exists()) {
      return snap.data();
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

/**
 * Save / update the budget limits of a couple
 */
export async function updateCoupleBudget(uid: string, budget: Budget) {
  const path = `${COUPLES_COLL}/${uid}`;
  try {
    await updateDoc(doc(db, COUPLES_COLL, uid), { budget });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Update the names or anniversary profile fields of a couple
 */
export async function updateCoupleProfileFields(uid: string, fields: Partial<CoupleProfile>) {
  const path = `${COUPLES_COLL}/${uid}`;
  try {
    await updateDoc(doc(db, COUPLES_COLL, uid), fields);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Record a transaction permanently
 */
export async function saveTransaction(uid: string, transaction: Transaction) {
  const path = `${COUPLES_COLL}/${uid}/${TRANS_SUB}/${transaction.id}`;
  try {
    await setDoc(doc(db, COUPLES_COLL, uid, TRANS_SUB, transaction.id), {
      ...transaction,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Delete a transaction permanently
 */
export async function eraseTransaction(uid: string, transactionId: string) {
  const path = `${COUPLES_COLL}/${uid}/${TRANS_SUB}/${transactionId}`;
  try {
    await deleteDoc(doc(db, COUPLES_COLL, uid, TRANS_SUB, transactionId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Save / Update a savings goal project
 */
export async function saveSavingsGoal(uid: string, goal: SavingsGoal) {
  const path = `${COUPLES_COLL}/${uid}/${GOALS_SUB}/${goal.id}`;
  try {
    await setDoc(doc(db, COUPLES_COLL, uid, GOALS_SUB, goal.id), {
      ...goal,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Delete a savings goal permanently
 */
export async function eraseSavingsGoal(uid: string, goalId: string) {
  const path = `${COUPLES_COLL}/${uid}/${GOALS_SUB}/${goalId}`;
  try {
    await deleteDoc(doc(db, COUPLES_COLL, uid, GOALS_SUB, goalId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Record a whisper alert notification
 */
export async function saveNotification(uid: string, notification: NotificationItem) {
  const path = `${COUPLES_COLL}/${uid}/${NOTIFS_SUB}/${notification.id}`;
  try {
    await setDoc(doc(db, COUPLES_COLL, uid, NOTIFS_SUB, notification.id), {
      ...notification,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Mark a single notification read / unread
 */
export async function updateNotificationReadState(uid: string, notifId: string, read: boolean) {
  const path = `${COUPLES_COLL}/${uid}/${NOTIFS_SUB}/${notifId}`;
  try {
    await updateDoc(doc(db, COUPLES_COLL, uid, NOTIFS_SUB, notifId), { read });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Delete a notification permanently
 */
export async function eraseNotification(uid: string, notifId: string) {
  const path = `${COUPLES_COLL}/${uid}/${NOTIFS_SUB}/${notifId}`;
  try {
    await deleteDoc(doc(db, COUPLES_COLL, uid, NOTIFS_SUB, notifId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Record a Buna Date ceremony
 */
export async function saveBunaDate(uid: string, bunaDate: BunaDate) {
  const path = `${COUPLES_COLL}/${uid}/${BUNA_SUB}/${bunaDate.id}`;
  try {
    await setDoc(doc(db, COUPLES_COLL, uid, BUNA_SUB, bunaDate.id), {
      ...bunaDate,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Delete a Buna Date ceremony permanently
 */
export async function eraseBunaDate(uid: string, id: string) {
  const path = `${COUPLES_COLL}/${uid}/${BUNA_SUB}/${id}`;
  try {
    await deleteDoc(doc(db, COUPLES_COLL, uid, BUNA_SUB, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

