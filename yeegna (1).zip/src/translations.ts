export interface Dictionary {
  appName: string;
  home: string;
  ledger: string;
  reports: string;
  savings: string;
  whispers: string;
  settings: string;
  roleSwitch: string;
  showBalances: string;
  hideBalances: string;
  logout: string;
  activeUnion: string;
  recordMoney: string;
  moneyOut: string;
  moneyIn: string;
  amountBirr: string;
  amount: string;
  sourceSpace: string;
  ourMoneySpace: string;
  wifeSpace: string;
  husbandSpace: string;
  spendingPlanCat: string;
  date: string;
  heartLabelNotes: string;
  rosesBuna: string;
  pledgeMutualSuit: string;
  dreamTitleName: string;
  parisTravel: string;
  requiredDreamAmt: string;
  goalCatGroup: string;
  deadlineDate: string;
  addMoneyDream: string;
  movingMoneyReduce: string;
  addedAmtBirr: string;
  addMoneyGoal: string;
  dreamGoalAchieved: string;
  adoringCongratulations: string;
  continueOurLegacy: string;
  daysSplendid: string;
  cozyNest: string;
  everyCupBuna: string;
  perfectPeace: string;
  householdSpaces: string;
  ourSharedBalance: string;
  jointNest: string;
  primaryShared: string;
  liveNest: string;
  allowance: string;
  myMoneySpace: string;
  individualTreats: string;
  selfCarePot: string;
  surprise: string;
  husbandSecret: string;
  surprisePot: string;
  aiInsights: string;
  letGemini: string;
  generateAiGuide: string;
  geminiCombing: string;
  ourCoPilotDecree: string;
  recommendationKeys: string;
  traditionalBunaTalks: string;
  highestSpends: string;
  recalculateSynergy: string;
  ourJointVision: string;
  flyToDreams: string;
  saved: string;
  target: string;
  addNewVision: string;
  ourSpendingHealth: string;
  used: string;
  limitCap: string;
  categoryBudgets: string;
  of: string;
  capsActive: string;
  adjustCeilings: string;
  cozyLedgerLines: string;
  completeHistory: string;
  noEntriesYet: string;
  by: string;
  wifeName: string;
  husbandName: string;
  wifeIdentity: string;
  husbandIdentity: string;
  signatureEmoji: string;
  configureSpendingPlans: string;
  establishCustomLimits: string;
  combinedMaxNest: string;
  planCap: string;
  sysAdminDetails: string;
  resettingClears: string;
  resetSanctuary: string;
  ourSharedSanctuary: string;
  customizeSpouse: string;
  testConnectionErr: string;
  bunaDateHarmony: string;
  bunaHarmonyLevel: string;
  trackBunaCeremony: string;
  logNewBunaTitle: string;
  bunaExplain: string;
  bunaTalkDate: string;
  whoBrewed: string;
  steamAgreements: string;
  steamExplain: string;
  saveBunaDate: string;
  activeBunaDatesCount: string;
  bunaDatesSub: string;
  noBunaDatesYet: string;
}

export const translations: Record<"en" | "am", Dictionary> = {
  en: {
    appName: "YeEgna",
    home: "Sweet Home",
    ledger: "Cozy Ledger",
    reports: "Visual Reports",
    savings: "Shared Dreams",
    whispers: "Couple Whispers",
    settings: "Nest Settings",
    roleSwitch: "Role Switch Matrix:",
    showBalances: "Show balances",
    hideBalances: "Hide balances",
    logout: "Log out",
    activeUnion: "Active Union:",
    recordMoney: "Record Money Activity",
    moneyOut: "Money Out 💸",
    moneyIn: "Money In 📈",
    amountBirr: "Amount in Birr",
    amount: "Amount",
    sourceSpace: "Source Money Space",
    ourMoneySpace: "🏩 Our Money Space",
    wifeSpace: "🌸 {wife}’s Fund Space",
    husbandSpace: "🧸 {husband}’s Fund Space",
    spendingPlanCat: "Spending plan category",
    date: "Date",
    heartLabelNotes: "Heart Label Notes",
    rosesBuna: "Roses, cozy traditional Buna, sweets... ☘️",
    pledgeMutualSuit: "Pledge Mutual Pursuit 🚀",
    dreamTitleName: "Dream Title name",
    parisTravel: "Paris travel, traditional wedding nested...",
    requiredDreamAmt: "Required Dream Goal Amount (Birr)",
    goalCatGroup: "Goal category group",
    deadlineDate: "Deadline date",
    addMoneyDream: "Add Money to Our Dream",
    movingMoneyReduce: "Moving money to this objective reduces your available cash from the general Our Money space.",
    addedAmtBirr: "Added Amount (Birr)",
    addMoneyGoal: "Add Money to Goal 💖",
    dreamGoalAchieved: "Dream Goal Achieved!",
    adoringCongratulations: "Adoring congratulations!",
    continueOurLegacy: "Continue Our Legacy",
    daysSplendid: "Day {days} of Our Splendid Journey",
    cozyNest: "Our cozy nest, built step-by-step",
    everyCupBuna: "Every cup of traditional Buna shared and every registry entry is a pledge to our holy future. We align hand-in-hand.",
    perfectPeace: '"Perfect financial peace lies not in how much you save, but how harmoniously you talk."',
    householdSpaces: "Household & Independent Spaces 💖",
    ourSharedBalance: "Our Shared Balance",
    jointNest: "Joint Nest",
    primaryShared: "Primary: Shared dream goals",
    liveNest: "Live Nest 🔋",
    allowance: "Allowance",
    myMoneySpace: "My Money Space",
    individualTreats: "Individual treats allowed",
    selfCarePot: "Self-Care Pot",
    surprise: "Surprise",
    husbandSecret: "Husband’s secret leaks",
    surprisePot: "Surprise Pot",
    aiInsights: "YeEgna Couple AI Insights (Gemini Assisted)",
    letGemini: "Let Gemini analyze your joint and private records dynamically, providing real-time coffee talks (Buna Advice) and financial harmony meters!",
    generateAiGuide: "Generate AI Synergy Guide",
    geminiCombing: "Gemini combing through your romantic diaries to compile tips...",
    ourCoPilotDecree: "OUR CO-PILOT DECREE",
    recommendationKeys: "Recommendation Keys",
    traditionalBunaTalks: "Traditional Buna Talks",
    highestSpends: "Highest Spends category:",
    recalculateSynergy: "Re-calculate synergy",
    ourJointVision: "Our Joint Vision Boards",
    flyToDreams: "Fly to dreams",
    saved: "Saved:",
    target: "Target:",
    addNewVision: "Add New Vision Board Pin",
    ourSpendingHealth: "Our Spending Health 💖",
    used: "Used:",
    limitCap: "Limit Cap:",
    categoryBudgets: "Category Budgets (Top Lists):",
    of: "of",
    capsActive: "Dynamic caps triggers are active",
    adjustCeilings: "Adjust ceilings",
    cozyLedgerLines: "Cozy ledger lines of togetherness",
    completeHistory: "Complete history",
    noEntriesYet: "No entries written yet. Record the first candlelight dinner or income above! 🌱",
    by: "by",
    wifeName: "Wife’s Name",
    husbandName: "Husband’s Name",
    wifeIdentity: "Wife’s Identity Settings",
    husbandIdentity: "Husband’s Identity Settings",
    signatureEmoji: "Signature Emoji Accent",
    configureSpendingPlans: "Configure Dynamic Spending plans (Monthly Goals)",
    establishCustomLimits: "Establish custom limits to trigger sweet alerts when your joint money out approaches thresholds!",
    combinedMaxNest: "Combined Max Monthly Nest Spending (Birr)",
    planCap: "Plan Cap (Birr)",
    sysAdminDetails: "System Administration Details",
    resettingClears: "Resetting clears the financial summaries and dream progress records in live browser storage, restoring initial presets (Belen & Michael dummy events) for audit reviews.",
    resetSanctuary: "Reset Sanctuary to default Ethiopian couples presets",
    ourSharedSanctuary: "Our Shared Sanctuary Profiles",
    customizeSpouse: "Customize spouse identities, custom signatures emojis, combined spending plan thresholds, and administrative setups.",
    testConnectionErr: "Please check your Firebase configuration.",
    bunaDateHarmony: "Buna & Fendisha Date Tracker ☕🍿",
    bunaHarmonyLevel: "Buna Harmony Level",
    trackBunaCeremony: "Traditional Ethiopian Buna (Coffee) Ceremonies",
    logNewBunaTitle: "Log a New Buna Ceremony Date",
    bunaExplain: "In Ethiopian tradition, sitting down for a warm cup of buna and freshly popped popcorn (fendisha) represents the holy hour of talking out issues, aligning goals, and expressing love.",
    bunaTalkDate: "Date of Ceremony",
    whoBrewed: "Who Brewed & Prepared the Buna?",
    steamAgreements: "What We Agreed Under the Buna Steam ☕💭",
    steamExplain: "e.g., 'To save more on cafe outings next week' or 'To dedicate more love focus'.",
    saveBunaDate: "Log Buna Harmony Date ♥",
    activeBunaDatesCount: "Buna Harmony Dates Shared",
    bunaDatesSub: "Traditional alignment ceremonies recorded by you and your partner",
    noBunaDatesYet: "No Buna Dates logged yet. Make some hot coffee, pop some fendisha, sit hand-in-hand, and record your first Buna Harmony date! ☕🍿"
  },
  am: {
    appName: "የኛ",
    home: "ዋና ገጽ",
    ledger: "የፍቅር መዝገብ",
    reports: "የወጪ ትንታኔ",
    savings: "የጋራ ህልሞች",
    whispers: "የልብ ሹክሹክታ",
    settings: "የጎጆችን ቅንጅት",
    roleSwitch: "የባለቤትነት ሚና ቀይር፦",
    showBalances: "ሂሳብ አሳይ",
    hideBalances: "ሂሳብ ደብቅ",
    logout: "ውጣ",
    activeUnion: "የፍቅር ህብረት፦",
    recordMoney: "ወጪ / ገቢ መዝግብ",
    moneyOut: "ወጪ 💸",
    moneyIn: "ገቢ 📈",
    amountBirr: "መጠን (በብር)",
    amount: "መጠን",
    sourceSpace: "የገንዘብ ምድብ",
    ourMoneySpace: "🏩 የጋራ ገንዘባችን",
    wifeSpace: "🌸 የ{wife} የግል ሂሳብ",
    husbandSpace: "🧸 የ{husband} የግል ሂሳብ",
    spendingPlanCat: "የወጪ ምድብ",
    date: "ቀን",
    heartLabelNotes: "ማስታወሻ / መግለጫ",
    rosesBuna: "የአበባ ስጦታ፣ የቡና ወጪዎች፣ ጣፋጭ ነገሮች... ☘",
    pledgeMutualSuit: "አዲስ ህልም ጀምር 🚀",
    dreamTitleName: "የህልሙ ስም",
    parisTravel: "የላንጋኖ ጉብኝት፣ የሰርግ ወጪ፣ አዲስ እቃዎች...",
    requiredDreamAmt: "የሚያስፈልገው ጠቅላላ ብር",
    goalCatGroup: "የህልሙ ምድብ",
    deadlineDate: "መፈጸሚያ ቀን",
    addMoneyDream: "ለህልማችን ገንዘብ እናስቀምጥ",
    movingMoneyReduce: "ለዚህ ህልም ገንዘብ ማስቀመጥ የጋራ ቀሪ ሂሳባችንን ይቀንሰዋል።",
    addedAmtBirr: "የሚቀመጠው ብር መጠኑ",
    addMoneyGoal: "ብር አስቀምጥ 💖",
    dreamGoalAchieved: "ህልማችን ተሳካ!",
    adoringCongratulations: "ከልብ ደስ ይላል!",
    continueOurLegacy: "ጉዟችንን እንቀጥል",
    daysSplendid: "በፍቅር ህይወታችን {days}ኛው ቀን",
    cozyNest: "ሞቅ ያለችው ጎጆአችን፣ ደረጃ በደረጃ...",
    everyCupBuna: "አብረን የምንጠጣው እያንዳንዱ የቡና ሲኒ እና የምንመዘግበው የወጪ መዝገብ ለወደፊት ህይወታችን የምንገባው የቃል ኪዳን አካል ነው። እጅ ለእጅ ተያይዘናል።",
    perfectPeace: '"ፍጹም የፋይናንስ ሰላም የሚገኘው በምናስቀምጠው ብር ብዛት ሳይሆን፣ በፍቅርና በግልጽነት ስንወያይ ነው።"',
    householdSpaces: "የጋራና የግል ሰነዶች 💖",
    ourSharedBalance: "የጋራ ቀሪ ሂሳባችን",
    jointNest: "የጋራ ጎጆ",
    primaryShared: "ቅድሚያ፦ ለጋራ ህልሞቻችን",
    liveNest: "ጎጆአችን ኃይል 🔋",
    allowance: "የግል ወጪ",
    myMoneySpace: "የግል ገንዘቤ",
    individualTreats: "የራስ ምርጫ ወጪዎች",
    selfCarePot: "የራስ እንክብካቤ",
    surprise: "የድንገተኛ ስጦታ",
    husbandSecret: "ለሚስት ደስ የሚል ስጦታ ማድረጊያ",
    surprisePot: "ድንገተኛ ስጦታዎች",
    aiInsights: "የኛ የጥንዶች ሰው ሰራሽ አስተዋይ (በጀሚኒ የታገዘ)",
    letGemini: "በጀሚኒ ጥበብ የጋራና የግል ወጪዎቻችሁን በዝርዝር በመተንተን፣ የቡና ሰዓት ወሬዎችን እና የፍቅር መስተጋብሮቻችሁን የሚገመግም ምክር ያግኙ!",
    generateAiGuide: "የጀሚኒን የስምምነት ምክር አሳይ",
    geminiCombing: "ጀሚኒ የፍቅር መዝገቦቻችሁን እየመረመረ የፋይናንስ ምክሮችን እያዘጋጀ ነው...",
    ourCoPilotDecree: "የጀሚኒ ምክረ-ሃሳብ",
    recommendationKeys: "ዋና ዋና የውሳኔ ሃሳቦች",
    traditionalBunaTalks: "በባህል ቡና ላይ የሚደረጉ ጨዋታዎች",
    highestSpends: "ከፍተኛው የወጣበት ምድብ፦",
    recalculateSynergy: "እንደገና አስላ",
    ourJointVision: "የወደፊት የጋራ ግቦቻችን",
    flyToDreams: "ወደ ህልማችን እንጓዝ",
    saved: "የተቀመጠው፦",
    target: "ግቡ፦",
    addNewVision: "አዲስ የወደፊት ህልም መዝግብ",
    ourSpendingHealth: "የወጪ አቅጣጫችን 💖",
    used: "የወጣው፦",
    limitCap: "ወሰኑ፦",
    categoryBudgets: "የእያንዳንዱ ምድብ የወጪ እቅድ፦",
    of: "ከ",
    capsActive: "የወጪ ገደቦች ንቁ ናቸው",
    adjustCeilings: "ወሰን አስተካክል",
    cozyLedgerLines: "አብሮነታችንን የሚያሳዩ የወጪና ገቢ መስመሮች",
    completeHistory: "ሙሉ ታሪክ",
    noEntriesYet: "እስካሁን ምንም መዝገብ አልተመዘገበም። የመጀመሪያውን የሻማ መብራት እራት ወይም ገቢ ከላይ ይመዝግቡ! 🌱",
    by: "በ",
    wifeName: "የሚስት ስም",
    husbandName: "የባል ስም",
    wifeIdentity: "የሚስት መገለጫ ቅንጅት",
    husbandIdentity: "የባል መገለጫ ቅንጅት",
    signatureEmoji: "የግል መለያ ገጸ-ባህሪ (ኢሞጂ)",
    configureSpendingPlans: "ተለዋዋጭ የወጪ እቅዶች (የወር ግቦች)",
    establishCustomLimits: "የጋራ ወጪያችሁ ከተገደበው ወሰን ሲያልፍ ጣፋጭ የጥንቃቄ ማስታወሻዎችን ይቀበላሉ!",
    combinedMaxNest: "ከፍተኛው ወርሃዊ የጋራ ወጪ (በብር)",
    planCap: "ክፍል ከፍተኛ ወጪ (ብር)",
    sysAdminDetails: "የስርዓቱ ማስተዳደሪያ",
    resettingClears: "ዳግም ማስጀመር ሁሉንም የፋይናንስ መረጃዎችና የህልም እድገቶችን ከብሮውዘሩ ላይ ያጠፋል፤ መጀመሪያ የነበሩትን የባህላዊ የኢትዮጵያ presets (የበለጥ እና ሚካኤል የሙከራ መረጃዎች) ይመልሳል።",
    resetSanctuary: "ጎጆአችንን ወደ መጀመሪያው የኢትዮጵያ ጥንዶች የሙከራ ይዘት ይመልሱ",
    ourSharedSanctuary: "የጋራ የፍቅር ጎጆ መገለጫዎች",
    customizeSpouse: "የጥንዶችን ማንነት፣ የግል ፊርማዎችን፣ አጠቃላይ የወጪ ወሰን እና አስተዳደራዊ ቅንብር ያብጁ።",
    testConnectionErr: "እባክዎን የፋየርቤዝ (Firebase) ቅንጅቶችን ይፈትሹ።",
    bunaDateHarmony: "የቡና እና ፈንድሻ ሰዓት መከታተያ ☕🍿",
    bunaHarmonyLevel: "የቡና ፍቅር መለኪያ",
    trackBunaCeremony: "የባህል ቡና መጠጣት ስርዓቶች",
    logNewBunaTitle: "አዲስ የቡና ሰዓት ስምምነት መዝግብ",
    bunaExplain: "በባህላችን መሰረት ጥንዶች አብረው ቡና ጠጥተው ፈንድሻ እየበሉ ቀስ አድርገው በተረጋጋ ፍቅር የፋይናንስ ወሬዎችን መወያየታቸው እና መግባባታቸው የፍቅር እና የስምምነት ምንጭ ነው።",
    bunaTalkDate: "የቡና ስርዓቱ የተከናወነበት ቀን",
    whoBrewed: "ቡናውን ያፈላው/ችው ማን ነበረ?",
    steamAgreements: "በቡናው ጢስ ስር የተስማማንበት ሃሳብ ☕💭",
    steamExplain: "ምሳሌ፦ 'በሚቀጥለው ሳምንት አላስፈላጊ የግል ወጪዎችን ለመቀነስ' ወይም 'በፍቅር ለመረዳዳት'።",
    saveBunaDate: "የቡና ትስስሩን መዝግብ ♥",
    activeBunaDatesCount: "የተጋሩ የቡና ቀናት",
    bunaDatesSub: "ከአጋርዎ ጋር በመሆን በፍቅርና በስምምነት ያሳለፏቸው ባህላዊ የቡና ጊዜያት",
    noBunaDatesYet: "እስካሁን ምንም የቡና ቀን አልተመዘገበም። በጋራ ጥሩ ቡና አፍልተው፣ ፈንድሻ ወይም ቆሎ አቅርበው በፍቅር ይንገሩ እና የመጀመሪያውን የቡና ቀን መዝግብ! ☕🍿"
  }
};
